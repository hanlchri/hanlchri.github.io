/**
 * ---------------------------------------------------------------------------
 * S-h-e-n-e-n-d-e-h-o-w-a--H-i-g-h--S-c-h-o-o-l--T-e-c-h-n-o-l-o-g-y--D-e-p-t
 * ----------------------------------------------------------------------------
 * FILE: DrawRectanglesApp 
 *
 * DATE:  11/22/2013
 *
 * PURPOSE: Starts up the Frame
 *
 * @author mr Hanley
 * @version 1.0
 * ----------------------------------------------------------------------------
 *
 * h-a-n-l-e-y.c-o-.-n-r------t-e-a-m-2-0-.-c-o-m----------------------------
 */
public class DrawRectanglesApp {
    public static void main(String[] args) {
        DrawRectanglesFrame fr = new DrawRectanglesFrame();
        fr.setBounds(100,100,1000,800);
        fr.setVisible(true);
    }

}
