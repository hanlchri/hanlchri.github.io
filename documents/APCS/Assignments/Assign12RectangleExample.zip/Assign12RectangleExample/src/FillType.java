
public enum FillType {
    hatched, solid, checker; 
}
