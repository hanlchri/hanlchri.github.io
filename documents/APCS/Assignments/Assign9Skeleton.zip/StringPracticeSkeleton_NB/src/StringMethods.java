/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * S-h-e-n-e-n-d-e-h-o-w-a--H-i-g-h--S-c-h-o-o-l--T-e-c-h-n-o-l-o-g-y--D-e-p-t
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *      FILE:       StringMethods.java
 *      DATE:       9/29/08 Original
 *      AUTHOR:     mr Hanley
 *      VERSION:    3.1
 *      PURPOSE:    String Methods to be completed by Student
 *                  1/5/2022: Added a second parameter to the password method
 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 * m-r-h-a-n-l-e-y-c-.c-o-m~~~~~~~~~~t-e-a-m-2-0-.-c-o-m~~~~~~~~~~~~~~~~~~~~~~
 */

import java.net.URL;
import java.io.BufferedReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.io.InputStreamReader;

public class StringMethods {

    /*****************************************************************
     *     public String pascalsTri(int levels) {
     * pre:  levels >= 3
     * post: returns a String consisting of Pascals' triangle with
     *       \t and \n as appropriate
     * example
     * levels = 3
     * \t\t1\n
     * \t1\t\t1\n
     * 1\t\t2\t\t1\n
     * 
     * @param levels levels of Pascal's triangle desired
     * 
     *
     *****************************************************************/
    public String pascalsTri(int levels) {
        return"";
    }

    /*****************************************************************
     *       public int numWords(String songTitle) {
     * pre: 
     * post: 
     *
     *****************************************************************/
    public int numWords(String songTitle) {
        return 0;
    }

    /*****************************************************************
     *       public String findTitle(String html)
     * pre:
     * post:
     *
     *****************************************************************/
    public String findTitle(String html) {
        return ""; 
    }
     /*****************************************************************
     *       public String findLinks(String html)
     * pre:
     * post:
     *
     *****************************************************************/
    public String[] findLinks(String html) {
        //count all hyperlinks
        //This code is just a little tip.....feel free to ignore
        int where;
        where = html.indexOf("<a href");
        System.out.println("where = "+ where);
        
        //Here is how to make an array a certain size during run time
        int count=0;
        ///....add up all the links found using count
        //...
        String[]links = new String[count];
        
        //Here is how to return a String array from a method.
        return links;
    }
    /*****************************************************************
     *       public boolean passwordVerify(String text, int level)
     * pre:  pass in pw and which level to test
     * post: true if password meets requirements for that level
     *
     *****************************************************************/
    public boolean passwordVerify(String text, int level) {
        return true;
    }
    /*****************************************************************
     *      public String openURL(String url) props to Josh Komoroske
     * pre:  pass in a url with http:// in front
     * post: returns the page source if possible
     *
     *****************************************************************/
    public String openURL(String url) throws Exception {
        URL server = null;
        try {
            server = new URL(url); //connect to the target URL
        } catch (MalformedURLException m) {
            throw new Exception(m);
        }

        BufferedReader in = null;
        try {
            in = new BufferedReader(new InputStreamReader(server.openStream())); //open a new stream buffer
        } catch (IOException ex) {
            throw new Exception(ex);
        }
        //Read in one line at at time and then add to pageSource
        String pageSource = "", sourceLine;
        try {
            while ((sourceLine = in.readLine()) != null) { //keep building the string until there is no more to read
                pageSource += sourceLine + "\n";
            }
            in.close();

        } catch (IOException ex) {
            throw new Exception(ex);
        }

        return pageSource;
    }
}