/**
 * ---------------------------------------------------------------------------
 * S-h-e-n-e-n-d-e-h-o-w-a--H-i-g-h--S-c-h-o-o-l--T-e-c-h-n-o-l-o-g-y--D-e-p-t
 * ---------------------------------------------------------------------------
 * FILE:    BlackJackFram
 *
 * DATE:    Original 5/20/2005 JBuilder
 *          Ported to NetBeans October 2016
 *
 * PURPOSE: Black Jack Game with Split Option for betting
 * 
 *          12/20/2016: Created a skeleton for AP Students
 *          who lost points for not commenting Assignment 8
 *
 *
 * @author mr Hanley
 * @version 2.0
 * ---------------------------------------------------------------------------
 *
 * h-a-n-l-e-y.c-o-.-n-r------t-e-a-m-2-0-.-c-o-m-----------------------------
 */
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.Timer;

public class BlackJackFrame extends javax.swing.JFrame implements ActionListener {

    Random r = new Random();
    //bummer, this is how the semester kids do it...
    //We really need a class to manage the 2 or 3 hands
    //This class would utilize an ArrayList to store the
    //card values
    int p1, p2, p3, p4, p5, p6, p7;  //player's card ranks
    int ps1, ps2, ps3, ps4, ps5, ps6, ps7; //player's split card ranks
    int d1, d2, d3, d4, d5, d6, d7;  //dealer's card ranks

    int numPcards, numDcards, numPSplitCards;
    ImageIcon[][] cards = new ImageIcon[4][14];  //suit then rank
    ImageIcon back;  //Use this for the back of a card!
    int state; //the current state of the game
    final static int PLAYER_PLAYIN = 0, DEALER_PLAYIN = 1;
    Timer t1 = new Timer(1500, this);
    int chips = 100; //player chips
    int bet;
    int playTotal, pSplitTotal, dealerTotal;
    boolean splitPossible=false, splitHands=false;  //by default no split

    //postcondition: read the card images in from disk into memory
    public void loadCards() {
        //I know, Ed, I know, I should have condensed this
        //but I did in my object oriented deck...
        //this was so the semester students could have 
        //something to finish as their skeleton only
        //loads one suit...
        try {
            Image image = ImageIO.read(new File("images/b2fv.gif"));
            back = new ImageIcon(image);//(ClassLoader.getSystemResource("images/b2fv.gif"));
            //Load the clubs Ace - 10
            for (int i = 1; i <= 10; i++) {
                String name = "images/c";
                name = name + i + ".gif";
                cards[0][i] = new ImageIcon(ImageIO.read(new File(name)));
                //cards[0][i] = new ImageIcon(ImageIO.read(new File(name));
            }
            //Load the jack, queen and king
            cards[0][11] = new ImageIcon(ImageIO.read(new File("images/cj.gif")));
            cards[0][12] = new ImageIcon(ImageIO.read(new File("images/cq.gif")));
            cards[0][13] = new ImageIcon(ImageIO.read(new File("images/ck.gif")));
            
            //Load the hearts Ace - 10
            for (int i = 1; i <= 10; i++) {
                String name = "images/h";
                name = name + i + ".gif";
                cards[1][i] = new ImageIcon(ImageIO.read(new File(name)));
            }
            //Load the jack, queen and king
            cards[1][11] =  new ImageIcon(ImageIO.read(new File("images/hj.gif")));
            cards[1][12] =  new ImageIcon(ImageIO.read(new File("images/hq.gif")));
            cards[1][13] =  new ImageIcon(ImageIO.read(new File("images/hk.gif")));
            
            //Load the spades Ace - 10
            for (int i = 1; i <= 10; i++) {
                String name = "images/s";
                name = name + i + ".gif";
                cards[2][i] = new ImageIcon(ImageIO.read(new File(name)));
            }
            //Load the jack, queen and king
            cards[2][11] = new ImageIcon(ImageIO.read(new File("images/sj.gif")));
            cards[2][12] = new ImageIcon(ImageIO.read(new File("images/sq.gif")));
            cards[2][13] = new ImageIcon(ImageIO.read(new File("images/sk.gif")));
            
            //Load the diamonds Ace - 10
            for (int i = 1; i <= 10; i++) {
                String name = "images/d";
                name = name + i + ".gif";
                cards[3][i] = new ImageIcon(ImageIO.read(new File(name)));
            }
            //Load the jack, queen and king
            cards[3][11] = new ImageIcon(ImageIO.read(new File("images/dj.gif")));
            cards[3][12] = new ImageIcon(ImageIO.read(new File("images/dq.gif")));
            cards[3][13] = new ImageIcon(ImageIO.read(new File("images/dk.gif")));
        } catch (IOException ex) {
            Logger.getLogger(BlackJackFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * This method will set both progress bars to reflect the chips and bet
     */
    public void updateProgressBars() {
        //I will finish in a new version eventually
    }

    public void updatePlTotal() {
        playTotal = sumCards(1);  //this is where you
        //can use your BlackJackHand class to figure totals
        pTotLBL.setText(playTotal + "");
    }

    public void actionPerformed(ActionEvent e) {
        //1/2 bet
//        if (e.getSource() == halfBetBUT) {
//            bet = (int) (chips * .5);
//            betTF.setText(new Integer(bet).toString());
//        }

        //Next Hand
        if (e.getSource() == nextBUT) {
            //get ready to accept bet
            resetHand();
            betBUT.setEnabled(true);
            nextBUT.setEnabled(false);
            splitBUT.setEnabled(false);
        }

        if (e.getSource() == betBUT) {
            String temp = betTF.getText();
            bet = Integer.parseInt(temp);
            if (bet > chips) {
                JOptionPane.showMessageDialog(null, "Too high bet", "Bet out of range",
                        JOptionPane.ERROR_MESSAGE);
            } else {
                betBUT.setEnabled(false);
                hitBUT.setEnabled(true);
                stayBUT.setEnabled(true);
                dealInitial();
                state = PLAYER_PLAYIN;
            }

        }
        //Check for hit button
        if (e.getSource() == hitBUT) {
            int x = dealNumber();
            int place;
            switch (numPcards) {
                case 2:
                    p3 = x;
                    place = ++numPcards;
                    p3LBL.setIcon(cards[dealSuit()][p3]);
                    break;
                case 3:
                    p4 = x;
                    place = ++numPcards;
                    p4LBL.setIcon(cards[dealSuit()][p4]);
                    break;
                case 4:
                    p5 = x;
                    place = ++numPcards;
                    p5LBL.setIcon(cards[dealSuit()][p5]);
            }
            if (sumCards(1) > 21) {//TODO, use your class
                endHand();
            }
        }
        //Check for timer event
        if (e.getSource() == t1) {
            //does the dealer have less than 17?
            if (sumCards(0) < 17) {  //Use your class!!!!
                dealerHit();
            } else {
                t1.stop();
                endHand();
            }
        }

        //set the chips to the number of chips the user has
        Integer c = new Integer(chips);
        chipsTF.setText(c.toString());

    }

    public void dealerHit() {
        if (numDcards == 5) {
            t1.stop();
            endHand();
        }
        int x = dealNumber();
        int place;
        numDcards++;
        switch (numDcards) {
            case 3:
                d3 = x;
                d3LBL.setIcon(cards[dealSuit()][d3]);
                break;
            case 4:
                d4 = x;
                d4LBL.setIcon(cards[dealSuit()][d4]);
                break;
            case 5:
                d5 = x;
                d5LBL.setIcon(cards[dealSuit()][d5]);
        }
        repaint();
        //Need help here...
        if (sumCards(0) > 21 || sumCards(0) > 16) {
            t1.stop();
            endHand();
        }

    }

//preconditions: both hands have ended, so its time to figure out who won
//postconditions:
    //NOTE: Need to add in features for player playing 2 hands
    public void endHand() {
        //disables the hit and stay buttons and enables the next Hand button
        stayBUT.setEnabled(false);
        hitBUT.setEnabled(false);
        nextBUT.setEnabled(true);

        if (sumCards(1) > 21) {
            statusTF.setText("Player busts");
            chips -= bet;
        } else if (sumCards(0) > 21) {
            statusTF.setText("Dealer busts");
            chips += bet;
        } //Check to see who's won?
        else if (sumCards(0) == sumCards(1)) {
            statusTF.setText("Dealer wins with a tie");
            chips -= bet;
        } else if (sumCards(0) < sumCards(1)) {
            statusTF.setText("Player wins with " + sumCards(1));
            chips += bet;
        } else {
            statusTF.setText("Dealer wins with " + sumCards(0));
            chips -= bet;
        }
        Integer c = new Integer(chips);
        chipsTF.setText(c.toString());
        updateProgressBars();
    }

    public void dealInitial() {
        //p1 = dealNumber();
        p1 = 10;  //why is this hardcoded? so I can test the
        //split feature!!!!!
        p1LBL.setIcon(cards[dealSuit()][10]);
        p2=10;
//p2 = dealNumber();
        p2LBL.setIcon(cards[dealSuit()][10]);

        d1 = dealNumber();
        d1LBL.setIcon(back);
        d2 = dealNumber();
        d2LBL.setIcon(cards[dealSuit()][d2]);
        
        //Added 12/9/2016 - Do we have a potential split?
        if(p1==p2){
            splitPossible=true;
            splitBUT.setEnabled(true);
        }
        repaint();

        numPcards = numDcards = 2;   //needs help!!
    }

////postcondition: read the card images in from disk into memory
//public void loadCards() {
//  back = new ImageIcon(ImageIO.read(new File("images/b2fv.gif"));
//  //Load the clubs Ace - 10
//  for (int i = 1; i <= 10; i++) {
//    String name = "images/c";
//    name = name + i + ".gif";
//    cards[0][i] = new ImageIcon(ImageIO.read(new File(name));
//  }
//  //Load the jack, queen and king
//  cards[0][11] = new ImageIcon(ImageIO.read(new File(
//      "images/cj.gif"));
//  cards[0][12] = new ImageIcon(ImageIO.read(new File(
//      "images/cq.gif"));
//  cards[0][13] = new ImageIcon(ImageIO.read(new File(
//      "images/ck.gif"));
//
// 
//
//}
//PostCondition: randomly returns a number from 1-13 where 1==Ace, 2==2, 11==Jack
//12==Queen, 13== King
    public int dealNumber() {
        return r.nextInt(13) + 1;
    }

//PostCondition: randomly returns 0-3 which represents the suit
    public int dealSuit() {
        return r.nextInt(4);
    }

//PostCondition: returns the sum of the cards for a specified player
//if who == 0, then return sum of dealer cards
//if who == 1, then return sum of player1 cards
    public int sumCards(int who) {

        boolean containsAce = false;
        int sum = 0;

      //Needs to be moved to the BlackJackHand Class.....
        return sum;
    }

    public void resetHand() {
//        Only button active should be bet ready
        hitBUT.setEnabled(false);
        stayBUT.setEnabled(false);
        splitBUT.setEnabled(false);
        nextBUT.setEnabled(false);
        
        d1 = d2 = d3 = d4 = d5 = 0;  //ugliness!!!!!!!!!!!!!!!!
        p1 = p2 = p3 = p4 = p5 = 0;
        ps1 = ps2 = ps3 = ps4 = ps5 = 0;
        d1LBL.setIcon(null);
        d2LBL.setIcon(null);
        d3LBL.setIcon(null);
        d4LBL.setIcon(null);
        d5LBL.setIcon(null);

        p1LBL.setIcon(null);
        p2LBL.setIcon(null);
        p3LBL.setIcon(null);
        p4LBL.setIcon(null);
        p5LBL.setIcon(null);
        
        //Set the split cards to null
        p1_SPLIT1_LBL.setIcon(null);
        p1_SPLIT2_LBL.setIcon(null);
        p1_SPLIT3_LBL.setIcon(null);
        p1_SPLIT4_LBL.setIcon(null);
        p1_SPLIT5_LBL.setIcon(null);

        statusTF.setText("Hanley's BlackJack");

    }

    ////////////////////////////////////////////////////////////////// 
    ////////      C O N S T R U C T O R S      ///////////////////////   
    //////////////////////////////////////////////////////////////////

    public BlackJackFrame() {

        try {
            //Load the background Image
            Image backImage = ImageIO.read(new File("images/background.jpg"));
            ImageIcon backIm = new ImageIcon(backImage);
            JLabel backLBL = new JLabel(backIm); //make a JLabel from background image
            //Set the bounds of the label to be the whole window
            backLBL.setBounds(0, 0, backIm.getIconWidth(), backIm.getIconHeight());
            getLayeredPane().add(backLBL, new Integer(Integer.MIN_VALUE));
            JPanel myPanel = new JPanel();
            myPanel.setOpaque(false);
            setContentPane(myPanel);
            initComponents();
            loadCards();
            
            chips = 100;
            bet = 10;
            resetHand();
            updateBars();
        } catch (IOException ex) {
            Logger.getLogger(BlackJackFrame.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    public void updateBars() {
        //Update the chips pb
        chipsTF.setText(chips + "");
        chipsPB.setValue(chips);
        //Now the bet is relative to how many chips we have
        //Mid Bet
        int midBet = chips / 2;
        betMidLBL.setText(midBet + "");
        int topBet = chips;
        betHighLBL.setText(topBet + "");
        betTF.setText(bet + "");
        
        //Adjust the progress bar
        betPB.setMaximum(chips);
        //Figure out 10% of the total chips to set the bet
        int tenPercent = (int)Math.round(chips * .10);
        betPB.setValue(tenPercent);
        betSLD.setValue(tenPercent);
    }  

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSplitPane1 = new javax.swing.JSplitPane();
        titleLBL = new javax.swing.JLabel();
        p5LBL = new javax.swing.JLabel();
        d1LBL = new javax.swing.JLabel();
        d2LBL = new javax.swing.JLabel();
        d3LBL = new javax.swing.JLabel();
        d4LBL = new javax.swing.JLabel();
        d5LBL = new javax.swing.JLabel();
        p1LBL = new javax.swing.JLabel();
        p2LBL = new javax.swing.JLabel();
        p1_SPLIT3_LBL = new javax.swing.JLabel();
        p4LBL = new javax.swing.JLabel();
        chipsPB = new javax.swing.JProgressBar();
        chipsLBL = new javax.swing.JLabel();
        betLBL = new javax.swing.JLabel();
        betPB = new javax.swing.JProgressBar();
        dealerLBL = new javax.swing.JLabel();
        playerLBL = new javax.swing.JLabel();
        betBUT = new javax.swing.JButton();
        hitBUT = new javax.swing.JButton();
        stayBUT = new javax.swing.JButton();
        nextBUT = new javax.swing.JButton();
        p3LBL = new javax.swing.JLabel();
        p1_SPLIT4_LBL = new javax.swing.JLabel();
        p1_SPLIT5_LBL = new javax.swing.JLabel();
        splitBUT = new javax.swing.JButton();
        playerLBL1 = new javax.swing.JLabel();
        p1_SPLIT2_LBL = new javax.swing.JLabel();
        p1_SPLIT1_LBL = new javax.swing.JLabel();
        betSLD = new javax.swing.JSlider();
        betTF = new javax.swing.JTextField();
        chipsTF = new javax.swing.JTextField();
        dtLBL = new javax.swing.JLabel();
        dtLBL1 = new javax.swing.JLabel();
        dtLBL2 = new javax.swing.JLabel();
        dTotLBL = new javax.swing.JLabel();
        pTotLBL = new javax.swing.JLabel();
        pSTotLBL = new javax.swing.JLabel();
        statusTF = new javax.swing.JTextField();
        statusLBL = new javax.swing.JLabel();
        betLowLBL = new javax.swing.JLabel();
        betMidLBL = new javax.swing.JLabel();
        betHighLBL = new javax.swing.JLabel();
        d6LBL = new javax.swing.JLabel();
        d7LBL = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        titleLBL.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        titleLBL.setForeground(new java.awt.Color(255, 255, 255));
        titleLBL.setText("Welcome to Black Jack!!");
        getContentPane().add(titleLBL);
        titleLBL.setBounds(120, 10, 440, 60);

        p5LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(p5LBL);
        p5LBL.setBounds(500, 300, 71, 96);

        d1LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(d1LBL);
        d1LBL.setBounds(100, 120, 71, 96);

        d2LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(d2LBL);
        d2LBL.setBounds(200, 120, 71, 96);

        d3LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(d3LBL);
        d3LBL.setBounds(300, 120, 71, 96);

        d4LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(d4LBL);
        d4LBL.setBounds(400, 120, 71, 96);

        d5LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(d5LBL);
        d5LBL.setBounds(500, 120, 71, 96);

        p1LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(p1LBL);
        p1LBL.setBounds(100, 300, 71, 96);

        p2LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(p2LBL);
        p2LBL.setBounds(200, 300, 71, 96);

        p1_SPLIT3_LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(p1_SPLIT3_LBL);
        p1_SPLIT3_LBL.setBounds(300, 430, 71, 96);

        p4LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(p4LBL);
        p4LBL.setBounds(400, 300, 71, 96);

        chipsPB.setForeground(new java.awt.Color(51, 51, 255));
        chipsPB.setMaximum(1000);
        chipsPB.setValue(100);
        chipsPB.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(0, 0, 0)));
        getContentPane().add(chipsPB);
        chipsPB.setBounds(930, 140, 450, 40);

        chipsLBL.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        chipsLBL.setText("Chips");
        getContentPane().add(chipsLBL);
        chipsLBL.setBounds(930, 80, 110, 60);

        betLBL.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        betLBL.setText("Bet");
        getContentPane().add(betLBL);
        betLBL.setBounds(930, 210, 70, 60);

        betPB.setForeground(new java.awt.Color(0, 204, 51));
        betPB.setMaximum(1000);
        betPB.setValue(30);
        betPB.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(0, 0, 0)));
        getContentPane().add(betPB);
        betPB.setBounds(930, 270, 450, 40);

        dealerLBL.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        dealerLBL.setForeground(new java.awt.Color(255, 255, 255));
        dealerLBL.setText("Dealer");
        getContentPane().add(dealerLBL);
        dealerLBL.setBounds(240, 50, 130, 60);

        playerLBL.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        playerLBL.setForeground(new java.awt.Color(255, 255, 255));
        playerLBL.setText("Player");
        getContentPane().add(playerLBL);
        playerLBL.setBounds(250, 230, 130, 60);

        betBUT.setBackground(new java.awt.Color(255, 153, 0));
        betBUT.setFont(new java.awt.Font("Rockwell", 1, 20)); // NOI18N
        betBUT.setText("Bet Ready");
        betBUT.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        betBUT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                betBUTActionPerformed(evt);
            }
        });
        getContentPane().add(betBUT);
        betBUT.setBounds(930, 360, 140, 40);

        hitBUT.setBackground(new java.awt.Color(255, 51, 0));
        hitBUT.setFont(new java.awt.Font("Rockwell", 1, 20)); // NOI18N
        hitBUT.setText("Hit");
        hitBUT.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        hitBUT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                hitBUTActionPerformed(evt);
            }
        });
        getContentPane().add(hitBUT);
        hitBUT.setBounds(1090, 360, 140, 40);

        stayBUT.setBackground(new java.awt.Color(255, 153, 255));
        stayBUT.setFont(new java.awt.Font("Rockwell", 1, 20)); // NOI18N
        stayBUT.setText("Stay");
        stayBUT.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        stayBUT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                stayBUTActionPerformed(evt);
            }
        });
        getContentPane().add(stayBUT);
        stayBUT.setBounds(1250, 360, 140, 40);

        nextBUT.setBackground(new java.awt.Color(102, 153, 0));
        nextBUT.setFont(new java.awt.Font("Rockwell", 1, 20)); // NOI18N
        nextBUT.setText("Next Hand->");
        nextBUT.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        nextBUT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nextBUTActionPerformed(evt);
            }
        });
        getContentPane().add(nextBUT);
        nextBUT.setBounds(1090, 420, 140, 40);

        p3LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(p3LBL);
        p3LBL.setBounds(300, 300, 71, 96);

        p1_SPLIT4_LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(p1_SPLIT4_LBL);
        p1_SPLIT4_LBL.setBounds(400, 430, 71, 96);

        p1_SPLIT5_LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(p1_SPLIT5_LBL);
        p1_SPLIT5_LBL.setBounds(500, 430, 71, 96);

        splitBUT.setBackground(new java.awt.Color(0, 204, 51));
        splitBUT.setFont(new java.awt.Font("Rockwell", 1, 20)); // NOI18N
        splitBUT.setText("Split");
        splitBUT.setBorder(javax.swing.BorderFactory.createMatteBorder(3, 3, 3, 3, new java.awt.Color(0, 0, 0)));
        splitBUT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                splitBUTActionPerformed(evt);
            }
        });
        getContentPane().add(splitBUT);
        splitBUT.setBounds(930, 420, 140, 40);

        playerLBL1.setFont(new java.awt.Font("Rockwell", 1, 24)); // NOI18N
        playerLBL1.setForeground(new java.awt.Color(255, 255, 255));
        playerLBL1.setText("Split");
        getContentPane().add(playerLBL1);
        playerLBL1.setBounds(30, 440, 60, 60);

        p1_SPLIT2_LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(p1_SPLIT2_LBL);
        p1_SPLIT2_LBL.setBounds(200, 430, 71, 96);

        p1_SPLIT1_LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(p1_SPLIT1_LBL);
        p1_SPLIT1_LBL.setBounds(100, 430, 71, 96);

        betSLD.setBackground(java.awt.Color.green);
        betSLD.setForeground(new java.awt.Color(0, 102, 102));
        betSLD.setOpaque(false);
        betSLD.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                betSLDStateChanged(evt);
            }
        });
        betSLD.addInputMethodListener(new java.awt.event.InputMethodListener() {
            public void caretPositionChanged(java.awt.event.InputMethodEvent evt) {
                betSLDCaretPositionChanged(evt);
            }
            public void inputMethodTextChanged(java.awt.event.InputMethodEvent evt) {
            }
        });
        getContentPane().add(betSLD);
        betSLD.setBounds(1000, 230, 200, 23);

        betTF.setBackground(java.awt.Color.red);
        betTF.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        betTF.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(0, 0, 0)));
        getContentPane().add(betTF);
        betTF.setBounds(1220, 220, 160, 40);

        chipsTF.setBackground(new java.awt.Color(255, 255, 0));
        chipsTF.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        chipsTF.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(0, 0, 0)));
        getContentPane().add(chipsTF);
        chipsTF.setBounds(1220, 90, 160, 40);

        dtLBL.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        dtLBL.setText("Tot");
        getContentPane().add(dtLBL);
        dtLBL.setBounds(830, 80, 70, 60);

        dtLBL1.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        dtLBL1.setText("Tot");
        getContentPane().add(dtLBL1);
        dtLBL1.setBounds(830, 250, 70, 60);

        dtLBL2.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        dtLBL2.setText("Tot");
        getContentPane().add(dtLBL2);
        dtLBL2.setBounds(830, 390, 70, 60);

        dTotLBL.setBackground(new java.awt.Color(255, 255, 51));
        dTotLBL.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        dTotLBL.setText("??");
        dTotLBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 5));
        dTotLBL.setOpaque(true);
        getContentPane().add(dTotLBL);
        dTotLBL.setBounds(830, 130, 50, 60);

        pTotLBL.setBackground(new java.awt.Color(255, 255, 51));
        pTotLBL.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        pTotLBL.setText("??");
        pTotLBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 5));
        pTotLBL.setOpaque(true);
        getContentPane().add(pTotLBL);
        pTotLBL.setBounds(830, 300, 50, 60);

        pSTotLBL.setBackground(new java.awt.Color(255, 255, 51));
        pSTotLBL.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        pSTotLBL.setText("??");
        pSTotLBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0), 5));
        pSTotLBL.setOpaque(true);
        getContentPane().add(pSTotLBL);
        pSTotLBL.setBounds(830, 430, 50, 60);

        statusTF.setBackground(java.awt.Color.orange);
        statusTF.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        statusTF.setBorder(javax.swing.BorderFactory.createMatteBorder(5, 5, 5, 5, new java.awt.Color(0, 0, 0)));
        getContentPane().add(statusTF);
        statusTF.setBounds(930, 490, 450, 50);

        statusLBL.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        statusLBL.setText("Status");
        getContentPane().add(statusLBL);
        statusLBL.setBounds(810, 490, 110, 60);

        betLowLBL.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        betLowLBL.setText("1");
        getContentPane().add(betLowLBL);
        betLowLBL.setBounds(920, 300, 50, 60);

        betMidLBL.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        getContentPane().add(betMidLBL);
        betMidLBL.setBounds(1120, 300, 50, 60);

        betHighLBL.setFont(new java.awt.Font("Rockwell", 1, 36)); // NOI18N
        getContentPane().add(betHighLBL);
        betHighLBL.setBounds(1320, 300, 90, 60);

        d6LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(d6LBL);
        d6LBL.setBounds(610, 120, 71, 96);

        d7LBL.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        getContentPane().add(d7LBL);
        d7LBL.setBounds(710, 120, 71, 96);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void stayBUTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_stayBUTActionPerformed
        //Dealer must play out their hand
        //show the dealer's down card
        d1LBL.setIcon(cards[dealSuit()][d1]);
        t1.start();
    }//GEN-LAST:event_stayBUTActionPerformed

    private void betSLDCaretPositionChanged(java.awt.event.InputMethodEvent evt) {//GEN-FIRST:event_betSLDCaretPositionChanged
        //Figure out where it currently sits
        int location = betSLD.getValue();
        //Since its based on 100, this is essentially a percentage of the bet
        bet = (int) Math.round(location * .01 * chips);
        //Adjust the text Field
        betTF.setText(bet + "");

    }//GEN-LAST:event_betSLDCaretPositionChanged

    private void betSLDStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_betSLDStateChanged
        //Figure out where it currently sits
        int location = betSLD.getValue();
        //Since its based on 100, this is essentially a percentage of the bet
        bet = (int) Math.round(location * .01 * chips);
        //Adjust the text Field
        betTF.setText(bet + "");
        //Tweak the bet Progress Bar
        betPB.setValue(bet);
    }//GEN-LAST:event_betSLDStateChanged

    private void betBUTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_betBUTActionPerformed
        bet = Integer.parseInt(betTF.getText());
        if (bet == 0) {
            statusTF.setText("MUST HAVE A BET!!");
        } else {
            //Let's start dealing cards
            betBUT.setEnabled(false);
            hitBUT.setEnabled(true);
            stayBUT.setEnabled(true);
            dealInitial();
            //if the players cards are the same, enable the split button
            if(p1==p2){//ranks match, you are allowed to split
                splitBUT.setEnabled(true);
            }
            state = PLAYER_PLAYIN;
        }
    }//GEN-LAST:event_betBUTActionPerformed

    private void hitBUTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_hitBUTActionPerformed
        int x = dealNumber();
        int place;
        switch (numPcards) {
            case 2:
                p3 = x;
                place = ++numPcards;
                p3LBL.setIcon(cards[dealSuit()][p3]);
                break;
            case 3:
                p4 = x;
                place = ++numPcards;
                p4LBL.setIcon(cards[dealSuit()][p4]);
                break;
            case 4:
                p5 = x;
                place = ++numPcards;
                p5LBL.setIcon(cards[dealSuit()][p5]);
        }
        if (sumCards(1) > 21) {
            endHand();
        }

        //Check for timer event
//    if (e.getSource () 
//        == t1) {
//      //does the dealer have less than 17?
//      if (sumCards(0) < 17) {
//            dealerHit();
//        } else {
//            t1.stop();
//            endHand();
//        }
//    }
//
//    //Check for stay button
//    if (e.getSource () 
//        == stayBUT) {
//      //Dealer must play out their hand
//      //show the dealer's down card
//      card1DealerLBL.setIcon(cards[dealSuit()][d1]);
//        t1.start();
//    }
        //set the chips to the number of chips the user has
//    Integer c = new Integer(chips);
//
//    chipsTF.setText (c.toString());        // TODO add your handling code here:
    }//GEN-LAST:event_hitBUTActionPerformed

    private void nextBUTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nextBUTActionPerformed
        //get ready to accept bet
        resetHand();
        betBUT.setEnabled(true);
        nextBUT.setEnabled(false);
        updateBars();
    }//GEN-LAST:event_nextBUTActionPerformed

    private void splitBUTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_splitBUTActionPerformed

        //Let's Split the hand into two separate hands and double the bet
        //Is there enough money to double your bet
        splitHands=true;
        //Disable the
        splitBUT.setEnabled(false);
        //Move the p2 card down and deal two more cards
        ps1 = p2;
        p1_SPLIT1_LBL.setIcon(p2LBL.getIcon());
        //Deal second for original
        p2LBL.setIcon(cards[dealSuit()][dealNumber()]);
        p1_SPLIT2_LBL.setIcon(cards[dealSuit()][dealNumber()]);
        
    }//GEN-LAST:event_splitBUTActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton betBUT;
    private javax.swing.JLabel betHighLBL;
    private javax.swing.JLabel betLBL;
    private javax.swing.JLabel betLowLBL;
    private javax.swing.JLabel betMidLBL;
    private javax.swing.JProgressBar betPB;
    private javax.swing.JSlider betSLD;
    private javax.swing.JTextField betTF;
    private javax.swing.JLabel chipsLBL;
    private javax.swing.JProgressBar chipsPB;
    private javax.swing.JTextField chipsTF;
    private javax.swing.JLabel d1LBL;
    private javax.swing.JLabel d2LBL;
    private javax.swing.JLabel d3LBL;
    private javax.swing.JLabel d4LBL;
    private javax.swing.JLabel d5LBL;
    private javax.swing.JLabel d6LBL;
    private javax.swing.JLabel d7LBL;
    private javax.swing.JLabel dTotLBL;
    private javax.swing.JLabel dealerLBL;
    private javax.swing.JLabel dtLBL;
    private javax.swing.JLabel dtLBL1;
    private javax.swing.JLabel dtLBL2;
    private javax.swing.JButton hitBUT;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JButton nextBUT;
    private javax.swing.JLabel p1LBL;
    private javax.swing.JLabel p1_SPLIT1_LBL;
    private javax.swing.JLabel p1_SPLIT2_LBL;
    private javax.swing.JLabel p1_SPLIT3_LBL;
    private javax.swing.JLabel p1_SPLIT4_LBL;
    private javax.swing.JLabel p1_SPLIT5_LBL;
    private javax.swing.JLabel p2LBL;
    private javax.swing.JLabel p3LBL;
    private javax.swing.JLabel p4LBL;
    private javax.swing.JLabel p5LBL;
    private javax.swing.JLabel pSTotLBL;
    private javax.swing.JLabel pTotLBL;
    private javax.swing.JLabel playerLBL;
    private javax.swing.JLabel playerLBL1;
    private javax.swing.JButton splitBUT;
    private javax.swing.JLabel statusLBL;
    private javax.swing.JTextField statusTF;
    private javax.swing.JButton stayBUT;
    private javax.swing.JLabel titleLBL;
    // End of variables declaration//GEN-END:variables
}
