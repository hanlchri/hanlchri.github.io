/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * S-h-e-n-e-n-d-e-h-o-w-a--H-i-g-h--S-c-h-o-o-l--T-e-c-h-n-o-l-o-g-y--D-e-p-t
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *      FILE:       PopulationComparator.java
 *      DATE:       May 4, 2018
 *      AUTHOR:     mr Hanley
 *      VERSION:    1.0
 *      PURPOSE:    See if two populations are within a threshold
 *                 
 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 * m-r-h-a-n-l-e-y-c-.c-o-m~~~~~~~~~~t-e-a-m-2-0-.-c-o-m~~~~~~~~~~~~~~~~~~~~~~
 */
import java.util.Comparator;

public class PopulationComparator implements Comparator {

    boolean ascending;

    public PopulationComparator(boolean asc) {
        ascending = asc;
    }

    public int compare(Object ter1, Object ter2) {
        Territory t1 = (Territory) ter1;
        Territory t2 = (Territory) ter2;

        if (ascending)
            return t1.pop - t2.pop;
        else
            return t2.pop - t1.pop;
    }
}
