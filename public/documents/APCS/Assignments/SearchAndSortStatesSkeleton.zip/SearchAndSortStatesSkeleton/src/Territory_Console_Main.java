
/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * S-h-e-n-e-n-d-e-h-o-w-a--H-i-g-h--S-c-h-o-o-l--T-e-c-h-n-o-l-o-g-y--D-e-p-t
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *      FILE:       Territory_Console_Main.java
 *      DATE:       Mar 24, 2017
 *      AUTHOR:     mr Hanley
 *      VERSION:    1.0
 *      PURPOSE:    Provide a menu and drive the searching and sorting of states
 *                  and cities
 *                 
 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 * m-r-h-a-n-l-e-y-c-.c-o-m~~~~~~~~~~t-e-a-m-2-0-.-c-o-m~~~~~~~~~~~~~~~~~~~~~~
 */
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Territory_Console_Main {

    public static void main(String[] args) {
        String currFile = "states and territories with 2012 populations.csv";
        Territory_Manager tm = null;
        try {
            tm = new Territory_Manager(currFile, "StatesAndPops");
        } catch (IOException ex) {
            Logger.getLogger(Territory_Console_Main.class.getName()).log(Level.SEVERE, null, ex);
        }

        Scanner input = new Scanner(System.in);
        while (true) {
            System.out.println("\t*************************************************");
            System.out.println("\t ***********************************************");
            System.out.println("\t  **         SEARCHING N SORTING             **");
            System.out.println("\t  **      SPONSORED BY HANLEYS HOOD          **");
            System.out.println("\t **------------------------------------------**");
            System.out.println("\t **   0 = Quit                                **");
            System.out.println("\t **   1 = Load Different Data                 **");
            System.out.println("\t **   2 = Display                             **");
            System.out.println("\t **   3 = Sequential Search (not sorted OK)   **");
            System.out.println("\t **   4 = Binary Search (must be sorted)      **");
            System.out.println("\t **   5 = Bin Search Recursive(must be sorted)**");
            System.out.println("\t **   6 = Bubble Sort by Name                 **");
            System.out.println("\t **   7 = Bubble Sort by Population           **");
            System.out.println("\t **   8 = Selection Sort by Name              **");
            System.out.println("\t **   9 = Selection Sort by Population        **");
            System.out.println("\t **  10 = Insertion Sort by Name              **");
            System.out.println("\t **  11 = Insertion Sort by Population        **");
            System.out.println("\t **  12 = Merge Sort by Name                  **");
            System.out.println("\t **  13 = Merge Sort by Population            **");
            System.out.println("\t **  14 = Learn about Sequential Search       **");
            System.out.println("\t **  15 = Learn about Binary Search           **");
            System.out.println("\t **  16 = Learn about Selection Sort          **");
            System.out.println("\t **  17 = Learn about Insertion Sort          **");
            System.out.println("\t **  18 = Learn about Merge Sort              **");
            System.out.println("\t **  19 = Scrambled Eggs                      **");
            System.out.println("\t **  20 = Verify Order                        **");
            System.out.println("\t **  21 = Load 5,000 cities and pops          **");
            System.out.println("\t **  22 = BONUS, Seq Search on Partial Name   **");
            System.out.println("\t  **                                         **");
            System.out.println("\t ***********************************************");
            System.out.println("\t*************************************************");
            int choice = input.nextInt();
            switch (choice) {
                case 0 -> {
                    System.out.println("Goodbye");
                    System.exit(0);
                }
                case 1 ->
                    System.out.println("What file to load?");

                case 2 -> {
                    DecimalFormat df = new DecimalFormat("###,###,000");
                    // Territory[] temp = tm.getList();
                    System.out.format("%-25s%20s\n", "Territory", "Population");
                    System.out.println("-----------------------------------------------");
                    for (Territory t : tm.getList()) {
                        String name = t.name;
                        if (t.name.length() > 24) {
                            name = name.substring(0, 24) + "*";
                        }
                        String pop = df.format(t.pop);
                        System.out.format("%-25s%20s\n", t.name, pop);
                        //System.out.println(t.name+"\t\t\t"+t.pop);
                    }
                }
                case 3 -> {
                    System.out.println("_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_");
                    System.out.println("_+_+_+_+_+_+_  Sequential Search  +_+_+_+__+_+_+_+_+_");
                    System.out.println("_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_");
                    System.out.println("_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_");

                    System.out.println("Please enter 1 for name, 2 for population range");
                    choice = input.nextInt();
                    if (choice == 1) {
                        System.out.println("Please enter in the territory name searching for");
                        System.out.println("Spaces matter but case DOES NOT");
                        input.skip("\n");
                        String target = input.nextLine();
                        ArrayList<Territory> terrs = new ArrayList<Territory>();

                        long time = System.currentTimeMillis();
                        SortResult s = tm.sequentialSearchName(target, terrs);
                        long time2 = System.currentTimeMillis();
                        s.timeElapsed = time2 - time;
                        //System.out.println(sr.toString());

                        if (terrs.size() == 0) {
                            System.out.println("*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*");
                            System.out.println("*(         NONE FOUND            (*");
                            System.out.println("*(           ;-(                 (*");
                            System.out.println("*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*");
                        } else {
                            System.out.println("Results...");
                            System.out.println("--------------------------------");

                            for (Territory t : terrs) {
                                System.out.println(t);
                            }
                            System.out.println(s);
                        }

                    }

                    if (choice == 2) {
                        System.out.println("Please enter in the desired population to search for:");
                        System.out.println("Next I will ask you for the tolerance around that size.");
                        int size = input.nextInt();
                        System.out.println("Okey-Dokey, plus or minus how many people:");
                        int threshold = input.nextInt();

                        String target = input.nextLine();
                        ArrayList<Territory> terrs = new ArrayList<Territory>();

                        long time = System.currentTimeMillis();
                        SortResult s = tm.sequentialSearchPop(size, threshold, terrs);
                        long time2 = System.currentTimeMillis();
                        s.timeElapsed = time2 - time;

                        if (terrs.size() == 0) {
                            System.out.println("*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*");
                            System.out.println("*(         NONE FOUND            (*");
                            System.out.println("*(           ;-(                 (*");
                            System.out.println("*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*");
                        } else {
                            System.out.println("Results...");
                            System.out.println("--------------------------------");

                            for (Territory t : terrs) {
                                System.out.println(t);
                            }
                            System.out.println(s);
                        }

                    }
                }

                case 4 -> {
                    System.out.println("_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_");
                    System.out.println("_+_+_+_+_+_+_  Binary Search  +_+_+_+_+_+__+_+_+_+_+_");
                    System.out.println("_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_");
                    System.out.println("_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_");

                    System.out.println("Please enter 1 for name, 2 for population range");
                    choice = input.nextInt();
                    ArrayList<Territory> terrs = new ArrayList<Territory>();
                    long time;// = System.currentTimeMillis();
                    SortResult s = null;// = tm.binarySearchName(target, terrs);
                    long time2;// = System.currentTimeMillis();

                    if (choice == 1) {
                        //-----------------Strings-----------------
                        System.out.println("Please enter in the territory name searching for");
                        System.out.println("Spaces matter but case DOES NOT");
                        input.skip("\n");
                        String target = input.nextLine();

                        time = System.currentTimeMillis();
                        s = tm.binarySearchName(target, terrs);
                        time2 = System.currentTimeMillis();
                        s.timeElapsed = time2 - time;

                    }
                    if (choice == 2) {
                        //-----------------Population-----------------
                        System.out.println("Please enter in the desired population to search for:");
                        System.out.println("Next I will ask you for the tolerance around that size.");
                        int size = input.nextInt();
                        System.out.println("Okey-Dokey, plus or minus how many people:");
                        int threshold = input.nextInt();

                        time = System.currentTimeMillis();
                        s = tm.binarySearchPop(size, threshold, terrs);
                        time2 = System.currentTimeMillis();
                        s.timeElapsed = time2 - time;

                    }

                    if (terrs.size() == 0) {
                        System.out.println("*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*");
                        System.out.println("*(         NONE FOUND            (*");
                        System.out.println("*(           ;-(                 (*");
                        System.out.println("*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*");
                    } else {
                        System.out.println("Results...");
                        System.out.println("--------------------------------");

                        for (Territory t : terrs) {
                            System.out.print(t);
                        }
                        System.out.println(s);
                    }

                }

                case 5 -> {
//                    System.out.println("_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_");
//                    System.out.println("_+_+_+_+_+_+_  Binary Search  +_+_+_+_+_+__+_+_+_+_+_");
//                    System.out.println("_+_+_+_+_+_     Recursive     +__+_+_+_+_+_+_+_+_+_+_");
//                    System.out.println("_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_");
//                    
//                    
//                    
//                    System.out.println("Please enter 1 for name, 2 for population range");
//                    choice = input.nextInt();
//                    if (choice == 1) {
//                        System.out.println("Please enter in the territory name searching for");
//                        System.out.println("Spaces matter but case DOES NOT");
//                        input.skip("\n");
//                        String target = input.nextLine();
//                        terrs = new ArrayList<Territory>();
//
//                       
//
//                        if (terrs.size() == 0) {
//                            System.out.println("*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*");
//                            System.out.println("*(         NONE FOUND            (*");
//                            System.out.println("*(           ;-(                 (*");
//                            System.out.println("*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*(*");
//                        } else {
//                            System.out.println("Results...");
//                            System.out.println("--------------------------------");
//
//                            for (Territory t : terrs) {
//                                System.out.println(t);
//                            }
//                            System.out.println(s);
//                        }
//
//                    }
                }
                case 6 -> {
                    System.out.println("_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_");
                    System.out.println("_+_+_+_+_+_+_  Bubble Sorting Dude(ette)  _+_+_+_+_+_");
                    System.out.println("_+_+_+_+_+_+_  Cross your fingers!!!!!!!!!_+_+_+_+_+_");
                    System.out.println("_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_");
                    System.out.print("B u b b l e  S o r t i n g  b y   N a m e");
                    for (int i = 0; i < 10; i++) {
                        System.out.print(".");

                        try {
                            Thread.sleep(400);
                        } catch (InterruptedException e) {
                        }
                    }
                    System.out.println("");
                    long time = System.currentTimeMillis();
                    SortResult sr = tm.bubbleSort("name");
                    long time2 = System.currentTimeMillis();
                    sr.timeElapsed = time2 - time;
                    System.out.println(sr.toString());
                }
                case 7 -> {
                    System.out.println("_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_");
                    System.out.println("_+_+_+_+_   Bubble Sorting by POPULATION  _+_+_+_+_+_");
                    System.out.println("_+_+_+_+_+_+_  Cross your fingers!!!!!!!!!_+_+_+_+_+_");
                    System.out.println("_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_+_");

                    System.out.println("");
                    System.out.println("Type 1 for Ascending, 2 for Descending..");
                    int ch = input.nextInt();
                    String option = "";
                    if (ch == 1) {
                        option = "pop asc";
                    } else {
                        option = "pop desc";
                    }

                    System.out.print("B u b b l e  S o r t i n g");
                    for (int i = 0; i < 10; i++) {
                        System.out.print(".");

                        try {
                            Thread.sleep(400);
                        } catch (InterruptedException e) {
                        }
                    }

                    System.out.println("");
                    long time = System.currentTimeMillis();
                    SortResult sr = tm.bubbleSort(option);
                    long time2 = System.currentTimeMillis();
                    sr.timeElapsed = time2 - time;

                    System.out.println(sr.toString());
                }

                case 8 -> {

                }

                case 9 -> {

                }
                case 10 -> {

                }
                case 19 -> {

                    System.out.println(
                            "$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$");
                    System.out.println(
                            "$%%$       S c r a m b l e d  E g g s            $%$%");
                    System.out.println(
                            "$%$%   M i x i n g   U p   T h e   A r r a y     $%$%");
                    System.out.println(
                            "$%$%   S p o n s o r e d  b y  t h e  H o o d    $%$%");
                    System.out.println(
                            "$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$%$");
                    tm.scramble();

                    System.out.print(
                            "S c r a m b l i n g");
                    for (int i = 0; i < 10; i++) {
                        System.out.print(".");
                        try {
                            Thread.sleep(400);
                        } catch (InterruptedException e) {
                        }
                    }
                }
                case 0x14 -> { //20 if you are wondering...

                    System.out.println(
                            "<L>><L>><:L<L>><L>><:L<L>><L>><:L<L>><L>><:L<L>><L>><:L");
                    System.out.println(
                            "<L>           V e r i f y  O r d e r                <:L");
                    System.out.println(
                            "<L>><L>><:L<L>><L>><:L<L>><L>><:L<L>><L>><:L<L>><L>><:L");
                    System.out.println(
                            "1 = Alpha Ascending\n2 = Population Ascending\n3 = Population Descending");
                    int cho = input.nextInt();
                    switch (cho) {
                        case 1:
                            System.out.println("I will check for ascending alphabetical...");
                            Territory t = tm.verify(Territory_Manager.NAME);
                            if (t == null) {
                                System.out.println("In Alpha Order Ascending");
                            } else {
                                System.out.println("Uh Oh, Not in Order, first record out of order is");
                                System.out.println(t);
                            }
                            break;
                        case 2:
                            System.out.println("I will check for ascending population...");
                            Territory to = tm.verify(Territory_Manager.ASCENDING);
                            if (to == null) {
                                System.out.println("In Population Order Ascending");
                            } else {
                                System.out.println("Uh Oh, Not in Order, first record out of order is");
                                System.out.println(to);
                            }
                            break;
                        case 3:
                            System.out.println("I will check for ascending population...");
                            Territory te = tm.verify(Territory_Manager.DESCENDING);
                            if (te == null) {
                                System.out.println("In Population Order Descending");
                            } else {
                                System.out.println("Uh Oh, Not in Order, first record out of order is");
                                System.out.println(te);
                            }
                            break;
                        default:
                            System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");
                            System.out.println("&          NOT AN OPTION BUDDY!!       &");
                            System.out.println("&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&");

                    }
                }

                case 21 -> {
                    System.out.println(
                            "()()()()()()()()()()()()()()()()()()()()()()()()()()(");
                    System.out.println(
                            "....     L o a d i n g  5 0 0 0  c i t i e s     ....");
                    System.out.println(
                            "....      G e t  R e a d y  F o r  T h e         ....");
                    System.out.println(
                            "....        S m o k e  A n d  F i r e            ....");
                    System.out.println(
                            "()()()()()()()()()()()()()()()()()()()()()()()()()()(");
                    try {
                        tm = new Territory_Manager("Top5000Population.csv", "CitiesStatesAndPops");
                    } catch (IOException ex) {
                        Logger.getLogger(Territory_Console_Main.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }

                default -> {
                    System.out.println(
                            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
                    System.out.println(
                            "%         NOT A THING!!                     %");
                    System.out.println(
                            "%         DO YOU WANT TO GET RICK ROLLED??  %");
                    System.out.println(
                            "%                                           %");
                    System.out.println(
                            "%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
                }
            }
        }
    }

}
