/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * S-h-e-n-e-n-d-e-h-o-w-a--H-i-g-h--S-c-h-o-o-l--T-e-c-h-n-o-l-o-g-y--D-e-p-t
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *      FILE:       SortResult.java
 *      DATE:       Mar 25, 2017
 *      AUTHOR:     mr Hanley
 *      VERSION:    1.0
 *      PURPOSE:    Hold Number Swaps, Number Comparisons and Time taken to sort 
 *                 
 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 * m-r-h-a-n-l-e-y-c-.c-o-m~~~~~~~~~~t-e-a-m-2-0-.-c-o-m~~~~~~~~~~~~~~~~~~~~~~
 */
import java.text.DecimalFormat;

public class SortResult {
    static DecimalFormat df = new DecimalFormat("###,###,#00");
    
    public int swaps;
    public int comparisons;
    public long timeElapsed;   //milliseconds to sort

    public String toString() {

        String topLine = "________________________________";
        String temp = new String(topLine);
        int length = temp.length();
        temp += "\n";
        //------------------------------Comparisons------------------------------
        String comparisonSection = "|   comparisons :" + df.format(comparisons);
        temp += comparisonSection;

        int difference = length - comparisonSection.length();  //This is the number of spaces needed

        for (int i = 0; i < difference - 1; i++) {
            temp += ' ';
        }
        temp += "|\n";

        //------------------------------Swaps------------------------------
        String swapSection = "|         swaps : " + df.format(swaps);
        temp += swapSection;

        difference = length - swapSection.length();  //This is the number of spaces needed

        for (int i = 0; i < difference - 1; i++) {
            temp += ' ';
        }
        temp += "|\n";

        //------------------------------Time------------------------------
        double timeSec = timeElapsed / 1000.0;
        timeSec *= 1000;
        timeSec = Math.round(timeSec);
        timeSec /= 1000;

        String timeSection = "|       time(s) : " + timeSec;
        temp += timeSection;

        difference = length - timeSection.length();  //This is the number of spaces needed

        for (int i = 0; i < difference - 1; i++) {
            temp += ' ';
        }
        temp += "|\n";
        temp += topLine + "\n";
        return temp;
    }

}
