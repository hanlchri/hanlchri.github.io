/**
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 * S-h-e-n-e-n-d-e-h-o-w-a--H-i-g-h--S-c-h-o-o-l--T-e-c-h-n-o-l-o-g-y--D-e-p-t
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *      FILE:       Territory_Manager.java
 *      DATE:       Mar 24, 2017
 *      AUTHOR:     mr Hanley
 *      VERSION:    1.0
 *      PURPOSE:    Class to manage an array of territories, allows searching and
 *                  sorting.  Show sequential, binary searches and selection,
 *                  insertion and merge sorts.  Also, bubble sort 
 *                 
 *                  4/26/2018:  Added a List for sequential sort 
 *                 
 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
 *
 * m-r-h-a-n-l-e-y-c-.c-o-m~~~~~~~~~~t-e-a-m-2-0-.-c-o-m~~~~~~~~~~~~~~~~~~~~~~
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.StringTokenizer;

public class Territory_Manager {

    final static int NAME = 0, ASCENDING = 1, DESCENDING = 2;

    private Territory[] list = new Territory[1];  //A list of different types of territories, 
    //states or cities
    
    ////////////////////////////////////////////////////////////////// 
    //////////////      C O N S T R U C T O R S      /////////////////   
    //////////////////////////////////////////////////////////////////

    public Territory_Manager(String filename, String format) throws IOException {
        //Try to open this file
        BufferedReader br = new BufferedReader(new FileReader(filename));
        ArrayList<Territory> temp = new ArrayList<Territory>();

        switch (format) {
            case "StatesAndPops":
                //Do some reading of da file...
                String line = br.readLine();
                while (line != null) {
                    Territory t = new State();
                    StringTokenizer st = new StringTokenizer(line, ",");
                    t.name = st.nextToken();
                    //get rid of the commas
                    t.pop = Integer.parseInt(st.nextToken().replaceAll("\"", ""));
                    temp.add(t);
                    line = br.readLine();  //go fetch next line of text file
                }
                break;
            case "CitiesStatesAndPops":
                //Do some reading of da file...
                line = br.readLine();
                while (line != null) {
                    Territory t = new City();
                    //StringTokenizer st = new StringTokenizer(line, ",");
                    //Find the first comma
                    int firstComma = line.indexOf(",");
                    //Grab the city name
                    t.name = line.substring(0, firstComma).trim();
                    //Find the second comma, we will ignore the state
                    int secondComma = line.indexOf(",", firstComma + 1);
                    //The population starts after the 2nd comma
                    String tempPop = line.substring(secondComma + 1);
                    //Strip the ""
                    tempPop = tempPop.replaceAll("\"", "");
                    //Strip the commas
                    tempPop = tempPop.replaceAll(",", "");

                    try {
                        t.pop = Integer.parseInt(tempPop);
                    } catch (NumberFormatException e) {
                        System.out.println("Here is the line " + line);
                    }
                    temp.add(t);
                    line = br.readLine();
                }
        }
        list = new Territory[temp.size()];  //allocate an array of the right size
        list = temp.toArray(list);  //force the arraylist into an array
    }
    //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
    //AAAAAAAAAAAAAAAAAAAAA  A C C E S S O R S  AAAAAAAAAAAAAAAAAAAAAAA
    //AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA

    public Territory[] getList() {
        return list;
    }
    //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM
    //MMMMMMMMMMMMMMM  S O R T I N G  A L G O S  MMMMMMMMMMMMMMMMMMMMMM
    //MMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMMM

    /**
     * ================================================================ 
     * SortResult bubbleSort(String byWhat)
     *
     * @param byWhat "name" or "pop" depending on what criteria to sort by
     * @param ascending true if we want the population ascending, false descending
     * @return SortResult with the number of comparisons, swaps and the time
     * Borrowed without permission:
     * https://mathbits.com/MathBits/Java/arrays/Bubble.htm
     * ================================================================
     */
    public SortResult bubbleSort(String byWhat) {
        //Method for comparing depends upon byWhat
        //NOTE: I just remembered, the sorter works depending
        //upon which way you want to sort when using population
        Comparator sorter = null;
        if (byWhat.equals("name")) {
            sorter = new AlphaComparator();
        } else if (byWhat.equals("pop asc")){
            sorter = new PopulationComparator(true);  
        }
        else {
            sorter = new PopulationComparator(false);
        }
        
        //Report results via a SortResult
        SortResult sr = new SortResult();
        sr.comparisons = sr.swaps = 0;
        
        Territory temp = null;  //Use this to swap

        int j; //inner loop does its thang....

        boolean flag = true;   // set flag to true to begin first pass
        //if flag is false, there were no comparisons
        //so we can stop bubble sorting,must be in order

        while (flag) {
            flag = false;    //set flag to false awaiting a possible swap
            for (j = 0; j < list.length - 1; j++) {
                sr.comparisons++;
                if(sorter.compare(list[j], list[j + 1]) > 0)
                {
                    sr.swaps++;
                    temp = list[j];                //swap elements
                    list[j] = list[j + 1];
                    list[j + 1] = temp;
                    flag = true;              //shows a swap occurred  
                }
            }
        }
        return sr;
    }

    /**
     * ================================================================ 
     * SortResult selectionSort(String byWhat)
     *
     * @param byWhat "name" or "pop" depending on what criteria to sort by
     * @return SortResult with the number of comparisons, swaps and the time
     *
     * ================================================================
     */
    public SortResult selectionSort(String byWhat) {
        //STUB CODED
        //Method for comparing depends upon byWhat
        Comparator sorter = null;
       
        
        SortResult sr = new SortResult();
        sr.comparisons = sr.swaps = 0;

        
        return sr;
    }
     /**
     * ================================================================ 
     * SortResult insertionSort(String byWhat)
     *
     * Stolen without permission https://www.geeksforgeeks.org/insertion-sort/
     * @param byWhat "name" or "pop" depending on what criteria to sort by
     * @return SortResult with the number of comparisons, swaps and the time
     *
     * ================================================================
     */
    public SortResult insertionSort(String byWhat) {
        //Method for comparing depends upon byWhat
        Comparator sorter = null;
        
        SortResult sr = new SortResult();
        sr.comparisons = sr.swaps = 0;

        
        return sr;
    }
 
    /**
     * ================================================================ 
     * void scramble()
     *
     * post: You know what we do, mix em and match up wilson, do it!!!
     *
     * ================================================================
     */
    public void scramble() {
        Territory temp = null;
        for (int i = 0; i < 10000; i++) {
            int first = (int) (Math.random() * list.length);
            int second = (int) (Math.random() * list.length);

            //swap
            temp = list[first];
            list[first] = list[second];
            list[second] = temp;
        }
    }

    /**
     * ================================================================ 
     *   public Territory verify(int which)
     *
     * post: returns # of comparisons and tries to find all occurrences of the
     * target in the name of the territory results will be size()=0 or populated
     * with all occurrences of the target in the list
     *
     * ================================================================
     */
    public Territory verify(int which) {
        Territory outOfOrder = null; //first Territory which breaks ordering

        if (which == NAME) {
            Comparator c = new AlphaComparator();

            for (int i = 1; i < list.length; i++) {
                Territory previous = list[i - 1];
                Territory current = list[i];

                if (c.compare(previous, current) > 0) {  //works like subtraction
                    //Previous is Larger Than Current, Get out of Here
                    return current;
                }
            }
            return null;

        }
        if (which == ASCENDING) {

            for (int i = 1; i < list.length; i++) {
                Territory previous = list[i - 1];
                Territory current = list[i];

                if (previous.pop > current.pop) {  //works like subtraction
                    //Previous is Larger Than Current, Get out of Here
                    return current;
                }
            }
            return null;
        }
        if (which == DESCENDING) {

            for (int i = 1; i < list.length; i++) {
                Territory previous = list[i - 1];
                Territory current = list[i];

                if (previous.pop < current.pop) {  //works like subtraction
                    //Previous is Larger Than Current, Get out of Here
                    return current;
                }
            }
            return null;
        }

        return null;

    }

    /**
     * ================================================================
     * SortResult sequentialSearchName(String target, List<Territory>)
     *
     * post: returns # of comparisons and tries to find all occurrences of the
     * target in the name of the territory results will be size()=0 or populated
     * with all occurrences of the target in the list
     *
     * ================================================================
     */
    public SortResult sequentialSearchName(String target, List<Territory> results) {
        Comparator c = new AlphaComparator();

        SortResult sr = new SortResult();
        sr.comparisons = sr.swaps = 0;

        results.clear();
        
        return sr;
    }

    /**
     * ================================================================
     * public SortResult sequentialSearchPop(int size, int threshold, List<Territory> results)
     *
     * post: returns # of comparisons and tries to find all occurrences of the
     * list where size-threshold <= population <= size+threshold  of the territory results 
     * will be size()=0 or populated
     * with all occurrences of the target in the list
     *
     * ================================================================
     */
    public SortResult sequentialSearchPop(int size, int threshold, List<Territory> results) {

        SortResult sr = new SortResult();
        sr.comparisons = sr.swaps = 0;
        int low = size - threshold;
        int high = size + threshold;
        
        results.clear();
        

        return sr;
    }

    /**
     * ================================================================ 
     *   public SortResult binarySearchName(String target, List<Territory>)
     *
     * post: returns # of comparisons and tries to find all occurrences of the
     *       target in the name of the territory results will be size()=0 or 
     *       populated with all occurrences of the target in the list
     *
     * ================================================================
     */
    public SortResult binarySearchName(String target, List<Territory> results) {
        Comparator c = new AlphaComparator();

        SortResult sr = new SortResult();
        sr.comparisons = sr.swaps = 0;

        results.clear();
      
        return sr;
    }
    
    /**
     * ================================================================ 
     *   public SortResult binarySearchPop(String target, List<Territory>)
     *
     * post: returns # of comparisons and tries to find all occurrences of the
     *       target in the name of the territory results will be size()=0 or populated
     *       with all occurrences of the target in the list
     *
     * ================================================================
     */
    public SortResult binarySearchPop(int size, int threshold, List<Territory> results) {
       
        SortResult sr = new SortResult();
        sr.comparisons = sr.swaps = 0;

        results.clear();
       
        return sr;
    }
}
