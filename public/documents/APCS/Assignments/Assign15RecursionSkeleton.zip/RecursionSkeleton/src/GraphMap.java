/**
 * ---------------------------------------------------------------------------
 * S-h-e-n-e-n-d-e-h-o-w-a--H-i-g-h--S-c-h-o-o-l--T-e-c-h-n-o-l-o-g-y--D-e-p-t
 * ----------------------------------------------------------------------------
 * FILE: GraphMap.java
 *
 * DATE: Original 2008 ish
 * PURPOSE: Represents a 2D image
 * @author mr Hanley
 * @version 3.14159
 * 
 * Characters in map;
 *      . = space
 *      * = wall
 *      @ = first click
 *      & = fill character  
 *  NOTE: only spaces and walls exist when reading in a text file
 *        the @ and &'s will be added by the Frame when filling!!
 * ----------------------------------------------------------------------------
 * h-a-n-l-e-y.c-o-.-n-r------t-e-a-m-2-0-.-c-o-m----------------------------
 */
import java.io.*;
import java.io.File;
import java.awt.image.BufferedImage;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.*;

public class GraphMap {

  private int width = 0, height = 0;

  private char[][] map; //two dimensional array of chars to represent image
  
    ////////////////////////////////////////////////////////////////// 
    ////////      C O N S T R U C T O R S      ///////////////////////   
    //////////////////////////////////////////////////////////////////

  /*****************************************************************
   *             public GraphMap(String file)
   * 
   * pre:    Get a valid filename
   * post:   Attempts to open file and read in a 50X50 map
   *         map has a sequence of .'s and *'s
   *
   *****************************************************************/

  public GraphMap(String file) {
    try {
      BufferedImage image = ImageIO.read(new File(file));
      setHeight(image.getHeight());
      setWidth(image.getWidth());
      map = new char[width][height];
      for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
          int pixel = image.getRGB(x, y);
          map[x][y] = pixel == 0xffffffff ? '.' : '*';
        }
      }
    }
    catch (IOException ex1) {
      System.out.println("IO EXCEPTION");
    }
  }
  //You add a constructor for reading in a .pict file
  //You add a constructor for reading in a .pict file
    public GraphMap(String file, boolean text) {
        //This constructor is for opening 
      

    }
  public int getWidth() {
    return width;
  }

  public int getHeight() {
    return height;
  }

  private void setHeight(int h) {
    height = h;
  }

  private void setWidth(int w) {
    width = w;
  }

  public boolean isInBounds(int x, int y) {
    //To DO, Finish Method, make sure this x and y is not off the map
      return true;  //stub coded
  }

  public char getPixel(int x, int y) {
      return map[x][y];
  }

  public char setPixel(int x, int y, char val) {
      //grab old character
      char temp = getPixel(x, y);
      map[x][y] = val;
      return temp;  
  }


}
