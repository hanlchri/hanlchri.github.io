/**
 * ---------------------------------------------------------------------------
 * S-h-e-n-e-n-d-e-h-o-w-a--H-i-g-h--S-c-h-o-o-l--T-e-c-h-n-o-l-o-g-y--D-e-p-t
 * ----------------------------------------------------------------------------
 * FILE: AreaFillApp.java
 *
 * DATE: Original 2008 ish
 * PURPOSE: Start up the AreaFill application
 * @author mr Hanley, largely rewritten by Josh Komoroske, 2009 Shen alum
 * @version 3.14159
 * 
 * ----------------------------------------------------------------------------
 * h-a-n-l-e-y.c-o-.-n-r------t-e-a-m-2-0-.-c-o-m----------------------------
 */

import javax.swing.*;
import java.awt.*;

public class AreaFillApp {

  public static void main(String[] args) {
    AreaFillFrame a = new AreaFillFrame("image2.bmp",12, 12, 0, 0);
    a.setTitle("JDK Area Fill");
    a.resizeToFit( -1, -1, 6, 27);
    a.setVisible(true);
  }

}
